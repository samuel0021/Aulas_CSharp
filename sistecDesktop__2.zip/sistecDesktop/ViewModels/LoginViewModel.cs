﻿using sistecDesktop.Commands;
using sistecDesktop.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace sistecDesktop.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        public ICommand MostrarMensagemCommand { get; }
        public ICommand OutroComandoCommand { get; }

        // Construtor - onde inicializamos os commands
        public LoginViewModel()
        {
            // Conecta o comando ao método que será executado
            MostrarMensagemCommand = new RelayCommand(MostrarMensagem);
            OutroComandoCommand = new RelayCommand(OutraAcao, PodeExecutarOutraAcao);
        }

        // Método executado quando o comando é acionado
        private void MostrarMensagem()
        {
            MessageBox.Show(
                "Você clicou no link!",
                "Informação",
                MessageBoxButton.OK,
                MessageBoxImage.Information
            );
        }

        // Outro exemplo de método
        private void OutraAcao()
        {
            MessageBox.Show("Outra ação executada!");
        }

        // Método que determina se o comando pode ser executado
        private bool PodeExecutarOutraAcao()
        {
            // Exemplo: só permite executar se alguma condição for verdadeira
            return true; // ou alguma lógica mais complexa
        }

        // Implementação do INotifyPropertyChanged (para binding de propriedades)
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
