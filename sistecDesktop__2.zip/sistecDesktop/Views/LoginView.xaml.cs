﻿using sistecDesktop.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sistecDesktop.Views
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();
        }

        //#region TextBlock "Esqueceu a senha"
        //private void txbForgotPass_MouseEnter(object sender, MouseEventArgs e)
        //{
        //    var tb = sender as TextBlock;

        //    this.Cursor = Cursors.Hand;
        //    tb.TextDecorations = TextDecorations.Underline;
        //}

        //private void txbForgotPass_MouseLeave(object sender, MouseEventArgs e)
        //{
        //    var tb = sender as TextBlock;

        //    this.Cursor = Cursors.Arrow;
        //    tb.TextDecorations = default;
        //}

        //private void txbForgotPass_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    var tb = sender as TextBlock;

        //    tb.Foreground = (Brush)Application.Current.Resources["brush-tropicalIndigo"];
        //}

        //private void txbForgotPass_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        //{
        //    var tb = sender as TextBlock;

        //    tb.Foreground = (Brush)Application.Current.Resources["brush-vibrantViolet"];
        //}
        //#endregion

    }
}