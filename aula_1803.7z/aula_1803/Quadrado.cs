﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_1803
{
    class Quadrado : Retangulo
    {
        public void InformarValores()
        {
            Console.Write("\nLado do quadrado: ");
            a = double.Parse(Console.ReadLine());
            b = a;

            CalculaArea();
        }
    }
}
