﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_1803
{
    class Retangulo : FiguraGeometrica
    {
        public double CalculaArea()
        {
            return a * b;
        }
    }
}
