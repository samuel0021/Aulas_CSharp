﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_1803
{
    internal class Circulo : FiguraGeometrica
    {
        public double CalculaArea()
        {
            return Math.PI * Math.Pow(raio, 2);
        }
    }
}
