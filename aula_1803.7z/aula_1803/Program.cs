﻿namespace aula_1803
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo r = new Retangulo();
            Quadrado q = new Quadrado();
            Circulo c = new Circulo();
            Triangulo t = new Triangulo();

            Console.WriteLine("   - Retângulo -");
            Console.Write("\nLado A: ");
            r.a = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nLado B: ");
            r.b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\nÁrea: " + r.CalculaArea());

            Console.WriteLine("\n----------------------------------\n");

            Console.WriteLine("   - Quadrado -");
            q.InformarValores();
            Console.WriteLine("\nÁrea: " + q.CalculaArea());

            Console.WriteLine("\n----------------------------------\n");

            Console.WriteLine("   - Círculo -");
            Console.Write("Raio: ");
            c.raio = double.Parse(Console.ReadLine());
            Console.WriteLine("Área: " + c.CalculaArea());
            Console.ReadLine();

            Console.WriteLine("\n----------------------------------\n");

            Console.WriteLine("   - Triângulo -");
            Console.Write("Lado A: ");
            t.a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Lado B: ");
            t.b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Lado C: ");
            t.c = Convert.ToDouble(Console.ReadLine());
        }
    }
}
