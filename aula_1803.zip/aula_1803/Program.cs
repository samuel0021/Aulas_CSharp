﻿namespace aula_1803
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo r = new Retangulo();
            Quadrado q = new Quadrado();

            Console.Write("\nDigite o lado A do retângulo: ");
            r.a = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nDigite o lado B do retângulo: ");
            r.b = Convert.ToDouble(Console.ReadLine());

            Console.Clear();
            Console.WriteLine("\n - Retângulo - \n\nLado A: " + r.a + "\nLado B: " + r.b);
            Console.WriteLine("\nÁrea: " + r.CalculaArea());

            Console.WriteLine("\n----------------------------------\n");

            q.InformarValores();
            Console.WriteLine("\n - Quadrado - \n\nLado: " + q.a);
            Console.WriteLine("\nÁrea: " + q.CalculaArea());
        }
    }
}
