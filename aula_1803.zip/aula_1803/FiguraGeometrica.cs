﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_1803
{
    public class FiguraGeometrica
    {
        private double _a, _b, _c, _raio;

        public double a
        {
            get { return _a; }
            set { _a = value; }
        }

        public double b
        {
            get { return _b; }
            set { _b = value; }
        }

        public double c
        {
            get { return _c; }
            set { _c = value; }
        }

        public double raio
        {
            get { return _raio; }
            set { _raio = value; }
        }
    }
}
